﻿namespace NekoSpace.API.GraphQL.AnimeNameControll
{
    public record DeleteTranslationNameInput(Guid Id);
}
