﻿namespace NekoSpace.API.GraphQL.AnimeNameControll
{
    public record DeleteTranslationNamePayload(bool Success);
}
