﻿
using NekoSpace.Data.Contracts.Enums;

namespace NekoSpace.API.Contracts.Models.GraphQL.AnimeNameControll
{
    public record UpdateTranslationNameInput(Guid Id, string Body, Language Language, bool IsOriginal);
}
