﻿namespace NekoSpace.API.GraphQL.Search
{
    public record SearchInput(string query, int first);
}
