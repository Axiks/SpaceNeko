﻿namespace NekoSpace.API.GraphQL.SetMainTitle
{
    public record SetMainTitleInput(Guid TitleId, bool isMain);
}
