﻿using NekoSpaceList.Models.Anime;

namespace NekoSpace.API.GraphQL.TranslationProposal
{
    public record CreateTranslationProposalPayload(bool isSucces);
}
