﻿namespace NekoSpace.API.GraphQL.TranslationProposalDecision
{
    public enum DecisionVariants
    {
        ACCEPT,
        REJECT
    }
}
