﻿namespace NekoSpace.API.GraphQL.TranslationProposalDecision
{
    public record SetDecisionTranslationProposalInput(Guid TitleId, DecisionVariants Decision);
}
