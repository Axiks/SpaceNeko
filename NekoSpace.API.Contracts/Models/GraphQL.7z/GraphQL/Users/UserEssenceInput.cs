﻿namespace NekoSpace.API.GraphQL.Users
{
    public record UserInput(string? about);
}
