﻿using NekoSpace.Data.Models.User;

namespace NekoSpace.API.GraphQL.Users
{
    public record UserPayload(NekoUser user);
}
